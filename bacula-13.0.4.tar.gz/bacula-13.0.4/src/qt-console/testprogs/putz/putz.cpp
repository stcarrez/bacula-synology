 
#include <QAbstractEventDispatcher>
#include <QApplication>

#include "putz.h"

Putz::Putz()
{
   printf("got to Putz Constructor\n");
   setupUi(this);
}
